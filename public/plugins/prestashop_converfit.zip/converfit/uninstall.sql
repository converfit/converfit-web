DROP TABLE `ps_converfit`;
