<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
if (!defined('_PS_VERSION_'))
	exit;

class Converfit extends Module
{
	private $html = '';

	public function __construct()
	{
		$this->name = 'converfit';
		$this->tab = 'converfit';
		$this->version = '1.0';
		$this->author = 'converfit';
		$this->need_instance = 0;

		parent::__construct();

		$this->displayName = $this->l('ConverFit');
		$this->description = $this->l('Converfit le ayuda a segmentar a sus clientes para incrementar su tasa de conversión.');
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.7.0.99');

		$this->confirmUninstall = $this->l('¿Desea desinstalar ConverFit para PrestaShop?');

		if (!Configuration::get('Converfit'))
		$this->warning = $this->l('No name provided.');
	}

	public function install()
	{
		echo "success";
		return (parent::install() AND $this->registerHook('Header'));
	}

	public function getContent()
    {
        $return = $this->_process_form();
        $return .= $this->_display_admin();
        return $return;
    }

    protected function _display_admin()
    {
        // Get default Language

        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        // Init Fields form array
        ?>


         <style>

		.form-field label {
    width: auto !important;
    padding: 0.2em 0.5em 0 0!important;
    text-align: left!important;
    }


		</style>



        <?php
        $bname = $_POST['brandconverfit'];
        $sql=  "CREATE TABLE "._DB_PREFIX_."converfit ( "."ID   INT NOT NULL, brand_name VARCHAR (120) NOT NULL); ";
			DB::getInstance()->Execute($sql);
			//~ echo "Success";
			$get_id= Db::getInstance()->executeS('select * from '._DB_PREFIX_.'converfit where ID="1"');


							$get_id= Db::getInstance()->executeS('select * from '._DB_PREFIX_.'converfit where ID="1"');

							  $brand = $get_id[0]['brand_name'];
							  $id = $get_id[0]['ID'];
						   if($id == '0')
								{
							   $brand = '';
							}
					   else if($id == '1'){

			  $brand = $get_id[0]['brand_name'];
									}


			if(!empty($get_id))
			{
				//~ $sql =DB::getInstance()->Execute("UPDATE `"._DB_PREFIX_."converfit` SET `brand_name`='".$bname."'");
				//~ echo "<p style='color: rgb(0, 128, 0); position: relative; top: 296px; background: none repeat scroll 0% 0% transparent;' align='center'>";
				//~ echo 'Brand Name was installed successfully';
				//~ echo "</p>";

				$fields_form = '<form class="wrap" method="post">
	 <div class="form-wrap">
		<h1>ConverFit para Prestashop</h1>
		<p>
			<a href="https://conver.fit/"  target="_blank">Acerca de conver.fit</a>
		</p>
		<br class="clear">
		<div id="col-container">
			<div id="col-right"></div>
			<div id="col-left">
				<div class="col-wrap">
					<div class="form-wrap">
						<h2>Cuenta Conver.fit</h2>
						<p>Configure su cuenta conver.fit</p>
						<form action="" method="post">
							<div class="form-field">
								<label for="brandconverfit">Brandname</label>
								<input name="brandconverfit" id="brandconverfit" pattern="[0-9a-z]{4,35}"  type="text" placeholder="'.$brand.'" required>

								<br>Valor actual: <b>"'.$brand.'"</b>
								<br/> <div class="dis_bname"></div>
								<p class="description">
									Use el brandname para conectar con su cuenta Conver.fit.<br/>
									<a href="https://conver.fit/app/access/signup" target="_blank">¿No tiene una cuenta? Cree una.</a>
								</p>
							</div>
							<p class="submit">
								<input type="submit" name="submit" id="submit" class="button button-primary" value="Guardar cambios">
							</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>';

			}
			else
			{
				//~ $a = DB::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'converfit`(`ID`,`brand_name`) VALUES ("1","'.$bname.'")');
				//~ echo "<p style='color: rgb(0, 128, 0); position: relative; top: 296px; background: none repeat scroll 0% 0% transparent;' align='center'>";
				//~ //echo 'Brand Name was installed successfully';
				//~ echo "</p>";

				$fields_form = '<form class="wrap" method="post">
				<div class="form-wrap">
				<h1>ConverFit para Prestashop</h1>
				<p>
				<a href="https://conver.fit/"  target="_blank">Acerca de conver.fit</a>
				</p>
				<br class="clear">
				<div id="col-container">
				<div id="col-right"></div>
				<div id="col-left">
				<div class="col-wrap">
					<div class="form-wrap">
						<h2>Cuenta Conver.fit</h2>
						<p>Configure su cuenta conver.fit</p>
						<form action="" method="post">
							<div class="form-field">
								<label for="brandconverfit">Brandname</label>
								<input name="brandconverfit" id="brandconverfit" pattern="[0-9a-z]{4,35}"  type="text" placeholder="'.$bname.'" required>
								<p class="description">
									Use el brandname para conectar con su cuenta Conver.fit.<br/>
									<a href="https://conver.fit/app/access/signup" target="_blank">¿No tiene una cuenta? Cree una.</a>
								</p>
							</div>
							<p class="submit">
								<input type="submit" name="submit" id="submit" class="button button-primary" value="Guardar cambios">
							</p>
						</form>
					</div>
				</div>
				</div>
				</div>
				</div>
				</form>';
}
        $form = new HelperForm();

        // Module, token and currentIndex
        $form->module = $this;
        $form->name_controller = $this->name;
        $form->token = Tools::getAdminTokenLite('AdminModules');
        $form->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        // Language
        $form->default_form_language = $default_lang;
        $form->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $form->title = $this->displayname;
        $form->show_toolbar = true;        // false -> remove toolbar
        $form->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
        $form->submit_action = 'submit'.$this->name;
        $form->toolbar_btn = array(
            'save' =>
            array(
                'desc' => $this->l('Guardar'),
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
                '&token='.Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' => array(
                'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Volver al listado')
            )
        );

        // Load current value
        $form->fields_value['my-var'] = Configuration::get(Tools::strtoupper($this->name).'_my-var');

      //  return $form->generateForm($fields_form);
        return $fields_form;
    }




	protected function _process_form()
    {
		if (isset($_POST['submit']))
		{
			$bname = $_POST['brandconverfit'];
			$sql=  "CREATE TABLE "._DB_PREFIX_."converfit ( "."ID   INT NOT NULL, brand_name VARCHAR (120) NOT NULL); ";
			DB::getInstance()->Execute($sql);
			//~ echo "Success";
			$get_id= Db::getInstance()->executeS('select * from '._DB_PREFIX_.'converfit where ID="1"');

			if(!empty($get_id))
			{
				$sql =DB::getInstance()->Execute("UPDATE `"._DB_PREFIX_."converfit` SET `brand_name`='".$bname."'");
				echo "<p style='color: rgb(0, 128, 0); position: relative; top: 296px; background: none repeat scroll 0% 0% transparent;' align='center'>";
				echo 'Brandname guardado correctamente';
				echo "</p>";
			}
			else
			{
				$a = DB::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'converfit`(`ID`,`brand_name`) VALUES ("1","'.$bname.'")');
				echo "<p style='color: rgb(0, 128, 0); position: relative; top: 296px; background: none repeat scroll 0% 0% transparent;' align='center'>";
				echo 'Brandname guardado correctamente';
				echo "</p>";
			}
		}
    }

	public function hookHeader($params)
	{
		$get_id= Db::getInstance()->executeS('select * from '._DB_PREFIX_.'converfit where ID="1"');

		 $brand = $get_id[0]['brand_name'];
		 $id = $get_id[0]['ID'];
	   if($id == '0')
			{

		}
   else if($id == '1'){

		$this->_html.= "<script src='https://conver.fit/script/cf.js?b={$brand}' type='text/javascript'></script>
		<img src='https://conver.fit/track/{$brand}/pixel.gif' height='1' width='1' style='display:none !important'/>";
		return $this->_html;
	}

}


		public function uninstall()
	{
		Configuration::deleteByName('converfit');

		$sql =DB::getInstance()->Execute("TRUNCATE ps_converfit");

		return parent::uninstall();
	}

}
