
<?php
include(ABSPATH . 'wp-config.php');
global $wpdb;
global $current_user;

$text = preg_replace("/[^a-z0-9]+/", "", $Brandname=$_POST['brandname']);

if(isset($_POST['submit_api']))
 {
	  $Brandname=$_POST['brandname'];
$api_get= $wpdb->get_results("Select * from converfit where id = '1'");
if ( null == $api_get ) {




	$sql= $wpdb->insert(
	'converfit',
	array(
		'brandname' => $Brandname
	),
	array(
		'%s'
	)
);
	 //$sql ="Insert into `convertfit` ('brandname') values( '".$Brandname."')";

	  $rez = $wpdb->query($sql);
	if($rez)
	{
		echo"sucess";
		}
 }

else
{
	$wpdb->update(
'converfit',
		array(
        'brandname' => $Brandname,
		),
		array('id' =>'1')
		);
 }
	}

 ?>

<div class="wrap">
<div class='form-wrap'>

<h1>ConverFit para Wordpress</h1>
<p>
<a href="https://conver.fit/" target='_blank'>Acerca de conver.fit</a>
</p>
<br class="clear">
<div id="col-container">
<div id="col-right"></div>
<div id='col-left'>
<div class='col-wrap'>
<div class='form-wrap'>
<h2>Cuenta Conver.fit</h2>
<p>Configure su cuenta conver.fit</p>
<form action="" method="post">
<div class="form-field">
<label for="brandconverfit">Brandname</label>
<?php
$api_get= $wpdb->get_results("Select * from converfit where id = '1'");
$brandname = $api_get[0]->brandname;
if ( null == $api_get ) {
	echo "<input name='brandname' id='brandconverfit' type='text'  pattern='[0-9a-z]{4,35}' placeholder='Inserte su brandname' value='' required >";
}
else
{

	echo "<input name='brandname' id='brandconverfit' type='text'  pattern='[0-9a-z]{4,35}' type='text' placeholder='".$brandname."' required >";
	}

?>

<p class="description">
Use el brandname para conectar con su cuenta Conver.fit.<br/>
<a href="https://conver.fit/app/access/signup" target='_blank'>¿No tiene una cuenta? Cree una.</a>
</p>
</div>
<p class="submit">
<input type="submit" name="submit_api" id="submit" class="button button-primary" value="Guardar cambios">
<?php
$api_get= $wpdb->get_results("Select * from converfit where id = '1'");
$brandname = $api_get[0]->brandname;
if ( null == $api_get ) {
	echo "Por favor, guarde su brandname.";
}
else
{

	echo "Valor actual: <b>" .$brandname."</b>";
	}

?>
</p>
</form>
</div>
</div>
</div>
</div>
</div>
</div>


<style>
	#p2{
	font-size:13px;
	color:red;
}
#p3{
	font-size:13px;
	color:red;
}
	</style>
