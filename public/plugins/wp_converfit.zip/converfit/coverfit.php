<?php /*
Plugin Name: ConverFit for Wordpress
Description: Converfit le ayuda a segmentar a sus clientes para incrementar su tasa de conversión.
Version: 1.0.0
Author: converfit
*/
include(ABSPATH . 'wp-config.php');
global $wpdb;
global $charset_collate;

add_action( 'admin_menu', 'converfit_menu_page' );
function converfit_menu_page()
{
	$page_title ="Converfit";
	$menu_title = "Converfit";
	$menu_slug = "Converfit";
	 $icon_url=plugin_dir_url( dirname( __FILE__ ) ).'converfit-wp/images/converfit-icon.png';
	add_menu_page($page_title, $menu_title, 'manage_options', $menu_slug, 'converfit_function', $icon_url, 6);
}
register_activation_hook( __FILE__, 'plugin_activation' ); /*for create the table after activate the plugin*/
// Plugin Activation Hook
function plugin_activation()
{
	$table_name = $wpdb->prefix.'converfit';
	$sql = "CREATE TABLE $table_name (
	id mediumint(9) NOT NULL AUTO_INCREMENT,
	brandname varchar(255) DEFAULT '' NOT NULL,
	UNIQUE KEY id (id)
	) $charset_collate;";
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
//~ if(isset($_POST['submit_api'])){
function hook_javascript() {

    global $wpdb;
	$api_get= $wpdb->get_results("Select * from converfit where id = '1'");
	$brandname = $api_get[0]->brandname;
	$id = $api_get[0]->id;

	if($id == '0')
	{

	}
	else if($id == '1')
	{
		echo  "<script src='https://conver.fit/script/cf.js?b={$brandname}' type='text/javascript'></script>
      <img src='https://conver.fit/track/{$brandname}/pixel.gif' height='1' width='1' style='display:none !important'/>";
	}

}
add_action('wp_head', 'hook_javascript');
//~ }
//register_deactivation_hook( __FILE__, 'plugin_deactivation' );
//register_deactivation_hook( __FILE__, 'plugin_deactivation' );

function converfit_function()
	{
		include('form.php');
	}
